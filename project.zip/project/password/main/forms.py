from django import forms

class PasswordForm(forms.Form):
    password_length = forms.IntegerField(widget = forms.NumberInput(attrs = {
        'class': 'lengthInput',
        'placeholder': 'Enter length',
    }), min_value = 4, max_value = 32)