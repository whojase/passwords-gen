from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required

from .forms import PasswordForm
from user.models import GeneratedPassword

import random
import string

def generete_password(length):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choices(characters, k = length))

@login_required(login_url = 'user/login/')
def index(request):
    form = PasswordForm(request.POST)
    password = None
    if request.method == 'POST':
        if form.is_valid():
            length = form.cleaned_data['password_length']
            password = generete_password(length)

            if request.user.is_authenticated:
                GeneratedPassword.objects.create(user = request.user, password = password)
    context = {
        'form': form,
        'password': password,
    }
    return render(request, 'main/index.html', context)
