from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm, UserChangeForm

from .models import Users

class UserRegisterForm(UserCreationForm):
    username = forms.CharField(widget = forms.TextInput(attrs = {
        'class': 'regInput',
        'id': 'login',
        'placeholder': 'Login',
    }))
    email = forms.CharField(widget = forms.EmailInput(attrs = {
        'class': 'regInput',
        'id': 'email',
        'placeholder': 'Email',
    }))
    password1 = forms.CharField(widget = forms.PasswordInput(attrs = {
        'class': 'regInput',
        'id': 'password',
        'placeholder': 'Password',
    }))
    password2 = forms.CharField(widget = forms.PasswordInput(attrs = {
        'class': 'regInput',
        'id': 'confirm-password',
        'placeholder': 'Confirm Password',
    }))

    class Meta:
        model = Users
        fields = [
            'username',
            'email',
            'password1',
            'password2',
        ]

class UserLoginForm(AuthenticationForm):
    username = forms.CharField(widget = forms.TextInput(attrs = {
        'class': 'regInput',
        'id': 'login',
        'placeholder': 'Login',
    }))
    password = forms.CharField(widget = forms.PasswordInput(attrs = {
        'class': 'regInput',
        'id': 'password',
        'placeholder': 'Password',
    }))

    class Meta:
        model = Users
        fields = [
            'username',
            'password',
        ]

class UserProfileForm(UserChangeForm):
    password = forms.CharField(widget = forms.PasswordInput(attrs = {
        'class': 'changeInput',
        'placeholder': 'Change Password',
    }))

    class Meta:
        model = Users
        fields = [
            'password',
        ]

    def save(self, commit=True):
        user = super().save(commit=False)
        if self.cleaned_data['password']:
            user.set_password(self.cleaned_data['password'])
        if commit:
            user.save()
        return user