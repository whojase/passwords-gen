from django.shortcuts import render, reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required

from .forms import UserRegisterForm, UserLoginForm, UserProfileForm
from .models import Users, GeneratedPassword

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(data = request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('user:login'))
        else:
            print(form.errors)
    else:
        form = UserRegisterForm(request.POST)
    context = {
        'form': form,
    }
    return render(request, 'user/register.html', context)

def login(request):
    if request.method == 'POST':
        form = UserLoginForm(data = request.POST)
        if form.is_valid():
            username = request.POST['username']
            password = request.POST['password']
            user = auth.authenticate(username = username, password = password)
            if user:
                auth.login(request, user)
                return HttpResponseRedirect(reverse('user:profile'))
        else:
            print(form.errors)

    else:
        form = UserLoginForm(request.POST)
    context = {
        'form': form,
    }
    return render(request, 'user/login.html', context)

@login_required(login_url = 'user/login/')
def profile(request):
    if request.method == 'POST':
        form = UserProfileForm(instance = request.user, data = request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('user:profile'))
        else:
            print(form.errors)
    else:
        user = request.user.username
        form = UserProfileForm(instance = request.user)
        passwords = GeneratedPassword.objects.filter(user=request.user) if request.user.is_authenticated else []
    context = {
        'form': form,
        'user': user,
        'passwords': passwords,
    }
    return render(request, 'user/profile.html', context)